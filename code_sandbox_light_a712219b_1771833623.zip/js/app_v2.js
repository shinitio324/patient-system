// グローバル変数
let allPatients = [];
let allHistory = [];
let currentEditId = null;
let importData = [];
let teamChart = null;
let diseaseChart = null;
let periodChart = null;

// 使用するテーブル名
const PATIENTS_TABLE = 'patients_v2';
const HISTORY_TABLE = 'patient_history';

// ユーザー名表示
function displayUserName() {
    const userId = sessionStorage.getItem('userId');
    const userNameElement = document.getElementById('userName');
    if (userNameElement) {
        userNameElement.textContent = userId || 'ゲスト';
    }
}

// ログアウト
function logout() {
    if (confirm('ログアウトしますか？')) {
        sessionStorage.removeItem('isAuthenticated');
        sessionStorage.removeItem('userId');
        sessionStorage.removeItem('loginTime');
        window.location.href = 'login.html';
    }
}

// 初期化
document.addEventListener('DOMContentLoaded', async () => {
    // ユーザー名表示
    displayUserName();
    
    // タブ切り替え
    setupTabNavigation();
    
    // フォーム送信イベント
    document.getElementById('patientForm').addEventListener('submit', handlePatientFormSubmit);
    document.getElementById('editForm').addEventListener('submit', handleEditFormSubmit);
    
    // 入院日変更時の自動計算
    document.getElementById('admissionDate').addEventListener('change', calculateDates);
    
    // 患者番号入力時の自動検索
    document.getElementById('patientId').addEventListener('blur', checkExistingPatient);
    
    // フィルター変更時の検索
    document.getElementById('filterTeam').addEventListener('change', searchPatients);
    document.getElementById('filterStatus').addEventListener('change', searchPatients);
    
    // 履歴検索
    document.getElementById('historySearchInput').addEventListener('input', filterHistory);
    
    // 初期データ読み込み
    await loadPatients();
    await loadHistory();
    updateDashboard();
    check2MonthsAlert();
});

// タブナビゲーション設定
function setupTabNavigation() {
    const tabButtons = document.querySelectorAll('.tab-btn');
    
    tabButtons.forEach(button => {
        button.addEventListener('click', async () => {
            const targetTab = button.getAttribute('data-tab');
            
            // すべてのタブボタンとコンテンツを非アクティブに
            tabButtons.forEach(btn => {
                btn.classList.remove('active', 'text-blue-600', 'border-b-2', 'border-blue-600');
                btn.classList.add('text-gray-600');
            });
            
            document.querySelectorAll('.tab-content').forEach(content => {
                content.classList.add('hidden');
            });
            
            // クリックされたタブをアクティブに
            button.classList.add('active', 'text-blue-600', 'border-b-2', 'border-blue-600');
            button.classList.remove('text-gray-600');
            document.getElementById(`${targetTab}-tab`).classList.remove('hidden');
            
            // グラフタブの場合は描画
            if (targetTab === 'charts') {
                await renderCharts();
            }
        });
    });
}

// 患者データ読み込み
async function loadPatients() {
    try {
        const response = await fetch(`/tables/${PATIENTS_TABLE}?limit=1000`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        allPatients = Array.isArray(data.data) ? data.data : [];
        
        updateDashboard();
        renderPatientsList();
        renderDischargeList();
    } catch (error) {
        console.error('患者データの読み込みに失敗しました:', error);
        allPatients = [];
        showNotification('患者データの読み込みに失敗しました', 'error');
    }
}

// 履歴データ読み込み
async function loadHistory() {
    try {
        const response = await fetch(`/tables/${HISTORY_TABLE}?limit=1000`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        allHistory = Array.isArray(data.data) ? data.data : [];
        
        renderHistoryList();
    } catch (error) {
        console.error('履歴データの読み込みに失敗しました:', error);
        allHistory = [];
    }
}

// ダッシュボード更新
function updateDashboard() {
    if (!Array.isArray(allPatients)) {
        console.error('allPatients is not an array:', allPatients);
        allPatients = [];
    }
    
    const totalPatients = allPatients.length;
    const admittedPatients = allPatients.filter(p => p.status === '入院中').length;
    const dischargedPatients = allPatients.filter(p => p.status === '退院').length;
    
    // 2か月経過患者を計算
    const today = new Date();
    const twoMonthsAgo = new Date();
    twoMonthsAgo.setMonth(twoMonthsAgo.getMonth() - 2);
    
    const twoMonthsPatients = allPatients.filter(p => {
        if (p.status !== '入院中') return false;
        const admissionDate = new Date(p.admissionDate);
        return admissionDate <= twoMonthsAgo;
    });
    
    // チーム別カウント
    const team1A = allPatients.filter(p => p.status === '入院中' && p.team === '1A');
    const team1B = allPatients.filter(p => p.status === '入院中' && p.team === '1B');
    
    // 統計カード更新
    document.getElementById('totalPatients').textContent = totalPatients;
    document.getElementById('admittedPatients').textContent = admittedPatients;
    document.getElementById('threeMonthsPatients').textContent = twoMonthsPatients.length;
    document.getElementById('dischargedPatients').textContent = dischargedPatients;
    
    // チーム統計更新
    document.getElementById('team1ACount').textContent = team1A.length;
    document.getElementById('team1BCount').textContent = team1B.length;
    
    // チーム別患者リスト
    renderTeamList('team1AList', team1A);
    renderTeamList('team1BList', team1B);
    
    // 2か月経過患者リスト表示
    renderTwoMonthsPatients(twoMonthsPatients);
}

// チーム別患者リスト表示
function renderTeamList(containerId, patients) {
    const container = document.getElementById(containerId);
    
    if (patients.length === 0) {
        container.innerHTML = '<p class="text-gray-500 text-sm">患者なし</p>';
        return;
    }
    
    let html = '<ul class="space-y-2">';
    patients.forEach(patient => {
        html += `
            <li class="text-sm">
                <span class="font-semibold">${patient.patientId}</span> - ${patient.name}
                ${patient.assignedNurse ? `<span class="text-gray-500 ml-2">(${patient.assignedNurse})</span>` : ''}
            </li>
        `;
    });
    html += '</ul>';
    
    container.innerHTML = html;
}

// 2か月超過アラートチェック
function check2MonthsAlert() {
    const today = new Date();
    const twoMonthsAgo = new Date();
    twoMonthsAgo.setMonth(twoMonthsAgo.getMonth() - 2);
    
    const twoMonthsPatients = allPatients.filter(p => {
        if (p.status !== '入院中') return false;
        const admissionDate = new Date(p.admissionDate);
        return admissionDate <= twoMonthsAgo;
    });
    
    const alertDiv = document.getElementById('twoMonthsAlert');
    const alertList = document.getElementById('twoMonthsAlertList');
    
    if (twoMonthsPatients.length === 0) {
        alertDiv.classList.add('hidden');
        return;
    }
    
    alertDiv.classList.remove('hidden');
    
    let html = `<p class="font-semibold mb-2">${twoMonthsPatients.length}名の患者が入院から2か月を経過しています：</p><ul class="list-disc list-inside space-y-1">`;
    twoMonthsPatients.forEach(patient => {
        const admissionPeriod = calculateAdmissionPeriod(patient.admissionDate);
        html += `<li>${patient.patientId} - ${patient.name} (${admissionPeriod}日経過)</li>`;
    });
    html += '</ul>';
    
    alertList.innerHTML = html;
}

// 2か月経過患者リスト表示
function renderTwoMonthsPatients(patients) {
    const container = document.getElementById('threeMonthsPatientsList');
    
    if (patients.length === 0) {
        container.innerHTML = '<p class="text-gray-500 text-center py-4">該当する患者はいません</p>';
        return;
    }
    
    let html = `
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">患者番号</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">患者名</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">チーム</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">病名</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">入院日</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">入院期間</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">主治医</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">受け持ちNS</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
    `;
    
    patients.forEach(patient => {
        const admissionPeriod = calculateAdmissionPeriod(patient.admissionDate);
        html += `
            <tr class="hover:bg-gray-50">
                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${patient.patientId}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${patient.name}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    <span class="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${patient.team === '1A' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800'}">
                        ${patient.team}
                    </span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${patient.disease}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${formatDate(patient.admissionDate)}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${admissionPeriod}日</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${patient.primaryPhysician}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${patient.assignedNurse || '-'}</td>
            </tr>
        `;
    });
    
    html += '</tbody></table>';
    container.innerHTML = html;
}

// 患者一覧表示
function renderPatientsList() {
    const container = document.getElementById('patientsList');
    
    if (allPatients.length === 0) {
        container.innerHTML = '<p class="text-gray-500 text-center py-4">登録された患者はいません</p>';
        return;
    }
    
    let html = `
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">患者番号</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">患者名</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">チーム</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">生年月日</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">病名</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">主治医</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">受け持ちNS</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">入院日</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ステータス</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">操作</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
    `;
    
    allPatients.forEach(patient => {
        const statusClass = patient.status === '入院中' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800';
        const teamClass = patient.team === '1A' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800';
        html += `
            <tr class="hover:bg-gray-50">
                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${patient.patientId}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${patient.name}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm">
                    <span class="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${teamClass}">
                        ${patient.team}
                    </span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${formatDate(patient.dateOfBirth)}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${patient.disease}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${patient.primaryPhysician}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${patient.assignedNurse || '-'}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${formatDate(patient.admissionDate)}</td>
                <td class="px-6 py-4 whitespace-nowrap">
                    <span class="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${statusClass}">
                        ${patient.status}
                    </span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                    <button onclick="editPatient('${patient.id}')" class="text-blue-600 hover:text-blue-900">
                        <i class="fas fa-edit"></i> 編集
                    </button>
                    <button onclick="deletePatient('${patient.id}')" class="text-red-600 hover:text-red-900">
                        <i class="fas fa-trash"></i> 削除
                    </button>
                </td>
            </tr>
        `;
    });
    
    html += '</tbody></table>';
    container.innerHTML = html;
}

// 退院管理リスト表示
function renderDischargeList() {
    const container = document.getElementById('dischargeList');
    const admittedPatients = allPatients.filter(p => p.status === '入院中');
    
    if (admittedPatients.length === 0) {
        container.innerHTML = '<p class="text-gray-500 text-center py-4">入院中の患者はいません</p>';
        return;
    }
    
    let html = `
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">患者番号</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">患者名</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">チーム</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">入院日</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">入院期間</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">90日後</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">3か月後</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">操作</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
    `;
    
    admittedPatients.forEach(patient => {
        const admissionPeriod = calculateAdmissionPeriod(patient.admissionDate);
        const teamClass = patient.team === '1A' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800';
        html += `
            <tr class="hover:bg-gray-50">
                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${patient.patientId}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${patient.name}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm">
                    <span class="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${teamClass}">
                        ${patient.team}
                    </span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${formatDate(patient.admissionDate)}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${admissionPeriod}日</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${formatDate(patient.ninetyDaysAfter)}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${formatDate(patient.threeMonthsAfter)}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <button onclick="dischargePatient('${patient.id}')" class="text-green-600 hover:text-green-900">
                        <i class="fas fa-sign-out-alt"></i> 退院処理
                    </button>
                </td>
            </tr>
        `;
    });
    
    html += '</tbody></table>';
    container.innerHTML = html;
}

// 履歴表示
function renderHistoryList() {
    const container = document.getElementById('historyList');
    
    if (!Array.isArray(allHistory)) {
        console.error('allHistory is not an array:', allHistory);
        allHistory = [];
    }
    
    if (allHistory.length === 0) {
        container.innerHTML = '<p class="text-gray-500 text-center py-4">履歴データはありません</p>';
        return;
    }
    
    // 日付順でソート
    const sortedHistory = [...allHistory].sort((a, b) => {
        return new Date(b.changeTimestamp) - new Date(a.changeTimestamp);
    });
    
    let html = '';
    sortedHistory.forEach(record => {
        const changeTypeClass = {
            '新規登録': 'bg-green-100 text-green-800',
            '情報更新': 'bg-blue-100 text-blue-800',
            '退院処理': 'bg-purple-100 text-purple-800',
            '削除': 'bg-red-100 text-red-800'
        }[record.changeType] || 'bg-gray-100 text-gray-800';
        
        html += `
            <div class="border border-gray-200 rounded-lg p-4">
                <div class="flex items-start justify-between mb-2">
                    <div>
                        <span class="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${changeTypeClass}">
                            ${record.changeType}
                        </span>
                        <span class="ml-2 font-semibold">${record.patientId} - ${record.patientName}</span>
                    </div>
                    <span class="text-sm text-gray-500">${formatDateTime(record.changeTimestamp)}</span>
                </div>
                ${record.changedFields ? `
                    <div class="text-sm text-gray-700 mt-2">
                        <span class="font-semibold">変更内容:</span> ${record.changedFields}
                    </div>
                ` : ''}
                ${record.oldValue && record.newValue ? `
                    <div class="text-sm text-gray-600 mt-1">
                        <span class="line-through">${record.oldValue}</span> → <span class="font-semibold">${record.newValue}</span>
                    </div>
                ` : ''}
            </div>
        `;
    });
    
    container.innerHTML = html;
}

// 履歴フィルタリング
function filterHistory() {
    const searchTerm = document.getElementById('historySearchInput').value.toLowerCase();
    
    if (!searchTerm) {
        renderHistoryList();
        return;
    }
    
    const filteredHistory = allHistory.filter(record => 
        record.patientId.toLowerCase().includes(searchTerm) ||
        record.patientName.toLowerCase().includes(searchTerm)
    );
    
    const container = document.getElementById('historyList');
    
    if (filteredHistory.length === 0) {
        container.innerHTML = '<p class="text-gray-500 text-center py-4">検索結果がありません</p>';
        return;
    }
    
    // 検索結果を表示
    const tempHistory = allHistory;
    allHistory = filteredHistory;
    renderHistoryList();
    allHistory = tempHistory; // 元のデータを復元
}

// 患者フォーム送信処理
async function handlePatientFormSubmit(event) {
    event.preventDefault();
    
    console.log('患者登録フォーム送信開始');
    
    const patientData = {
        patientId: document.getElementById('patientId').value,
        name: document.getElementById('name').value,
        dateOfBirth: document.getElementById('dateOfBirth').value,
        disease: document.getElementById('disease').value,
        primaryPhysician: document.getElementById('primaryPhysician').value,
        admissionDate: document.getElementById('admissionDate').value,
        team: document.getElementById('team').value,
        assignedNurse: document.getElementById('assignedNurse').value || '',
        status: '入院中'
    };
    
    console.log('入力データ:', patientData);
    
    // 日付の自動計算
    const admissionDate = new Date(patientData.admissionDate);
    
    // 90日後
    const ninetyDaysAfter = new Date(admissionDate);
    ninetyDaysAfter.setDate(ninetyDaysAfter.getDate() + 90);
    
    // 3か月後
    const threeMonthsAfter = new Date(admissionDate);
    threeMonthsAfter.setMonth(threeMonthsAfter.getMonth() + 3);
    
    patientData.ninetyDaysAfter = ninetyDaysAfter.toISOString();
    patientData.threeMonthsAfter = threeMonthsAfter.toISOString();
    patientData.admissionPeriodDays = 0;
    
    console.log('送信データ:', patientData);
    
    try {
        const response = await fetch(`/tables/${PATIENTS_TABLE}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(patientData)
        });
        
        console.log('レスポンスステータス:', response.status);
        
        if (response.ok) {
            const newPatient = await response.json();
            console.log('登録成功:', newPatient);
            
            // 履歴を記録
            await addHistory(newPatient.id, patientData.patientId, patientData.name, '新規登録', '患者情報', '', '新規患者登録');
            
            showNotification('患者情報を登録しました', 'success');
            resetForm();
            await loadPatients();
            await loadHistory();
            check2MonthsAlert();
        } else {
            const errorText = await response.text();
            console.error('登録エラー:', response.status, errorText);
            throw new Error('登録に失敗しました: ' + errorText);
        }
    } catch (error) {
        console.error('患者登録エラー:', error);
        showNotification('患者情報の登録に失敗しました: ' + error.message, 'error');
    }
}

// 編集フォーム送信処理
async function handleEditFormSubmit(event) {
    event.preventDefault();
    
    const id = document.getElementById('editId').value;
    const oldPatient = allPatients.find(p => p.id === id);
    
    const patientData = {
        patientId: document.getElementById('editPatientId').value,
        name: document.getElementById('editName').value,
        dateOfBirth: document.getElementById('editDateOfBirth').value,
        disease: document.getElementById('editDisease').value,
        primaryPhysician: document.getElementById('editPrimaryPhysician').value,
        admissionDate: document.getElementById('editAdmissionDate').value,
        dischargeDate: document.getElementById('editDischargeDate').value || null,
        status: document.getElementById('editStatus').value,
        team: document.getElementById('editTeam').value,
        assignedNurse: document.getElementById('editAssignedNurse').value || ''
    };
    
    // 日付の再計算
    const admissionDate = new Date(patientData.admissionDate);
    const ninetyDaysAfter = new Date(admissionDate);
    ninetyDaysAfter.setDate(ninetyDaysAfter.getDate() + 90);
    
    const threeMonthsAfter = new Date(admissionDate);
    threeMonthsAfter.setMonth(threeMonthsAfter.getMonth() + 3);
    
    patientData.ninetyDaysAfter = ninetyDaysAfter.toISOString();
    patientData.threeMonthsAfter = threeMonthsAfter.toISOString();
    patientData.admissionPeriodDays = calculateAdmissionPeriod(patientData.admissionDate);
    
    // 変更内容を記録
    const changes = [];
    if (oldPatient.team !== patientData.team) changes.push(`チーム: ${oldPatient.team} → ${patientData.team}`);
    if (oldPatient.assignedNurse !== patientData.assignedNurse) changes.push(`受け持ちNS: ${oldPatient.assignedNurse || 'なし'} → ${patientData.assignedNurse || 'なし'}`);
    if (oldPatient.status !== patientData.status) changes.push(`ステータス: ${oldPatient.status} → ${patientData.status}`);
    
    try {
        const response = await fetch(`/tables/${PATIENTS_TABLE}/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(patientData)
        });
        
        if (response.ok) {
            // 履歴を記録
            if (changes.length > 0) {
                await addHistory(id, patientData.patientId, patientData.name, '情報更新', changes.join(', '), '', '');
            }
            
            showNotification('患者情報を更新しました', 'success');
            closeEditModal();
            await loadPatients();
            await loadHistory();
            check2MonthsAlert();
        } else {
            throw new Error('更新に失敗しました');
        }
    } catch (error) {
        console.error('患者更新エラー:', error);
        showNotification('患者情報の更新に失敗しました', 'error');
    }
}

// 患者編集
function editPatient(id) {
    const patient = allPatients.find(p => p.id === id);
    if (!patient) return;
    
    document.getElementById('editId').value = patient.id;
    document.getElementById('editPatientId').value = patient.patientId;
    document.getElementById('editName').value = patient.name;
    document.getElementById('editDateOfBirth').value = formatDateForInput(patient.dateOfBirth);
    document.getElementById('editDisease').value = patient.disease;
    document.getElementById('editPrimaryPhysician').value = patient.primaryPhysician;
    document.getElementById('editAdmissionDate').value = formatDateForInput(patient.admissionDate);
    document.getElementById('editDischargeDate').value = patient.dischargeDate ? formatDateForInput(patient.dischargeDate) : '';
    document.getElementById('editStatus').value = patient.status;
    document.getElementById('editTeam').value = patient.team;
    document.getElementById('editAssignedNurse').value = patient.assignedNurse || '';
    
    document.getElementById('editModal').classList.remove('hidden');
    document.getElementById('editModal').classList.add('flex');
}

// 編集モーダルを閉じる
function closeEditModal() {
    document.getElementById('editModal').classList.add('hidden');
    document.getElementById('editModal').classList.remove('flex');
}

// 患者削除
async function deletePatient(id) {
    if (!confirm('この患者情報を削除してもよろしいですか？')) {
        return;
    }
    
    const patient = allPatients.find(p => p.id === id);
    
    try {
        // 履歴を記録
        await addHistory(id, patient.patientId, patient.name, '削除', '患者情報削除', '', '');
        
        const response = await fetch(`/tables/${PATIENTS_TABLE}/${id}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            showNotification('患者情報を削除しました', 'success');
            await loadPatients();
            await loadHistory();
            check2MonthsAlert();
        } else {
            throw new Error('削除に失敗しました');
        }
    } catch (error) {
        console.error('患者削除エラー:', error);
        showNotification('患者情報の削除に失敗しました', 'error');
    }
}

// 退院処理
async function dischargePatient(id) {
    if (!confirm('この患者を退院処理してもよろしいですか？')) {
        return;
    }
    
    const patient = allPatients.find(p => p.id === id);
    if (!patient) return;
    
    const today = new Date().toISOString();
    patient.status = '退院';
    patient.dischargeDate = today;
    
    try {
        const response = await fetch(`/tables/${PATIENTS_TABLE}/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(patient)
        });
        
        if (response.ok) {
            // 履歴を記録
            await addHistory(id, patient.patientId, patient.name, '退院処理', '退院日', '', formatDate(today));
            
            showNotification('退院処理を完了しました', 'success');
            await loadPatients();
            await loadHistory();
            check2MonthsAlert();
        } else {
            throw new Error('退院処理に失敗しました');
        }
    } catch (error) {
        console.error('退院処理エラー:', error);
        showNotification('退院処理に失敗しました', 'error');
    }
}

// 履歴追加
async function addHistory(patientRecordId, patientId, patientName, changeType, changedFields, oldValue, newValue) {
    const historyData = {
        patientRecordId,
        patientId,
        patientName,
        changeType,
        changedFields,
        oldValue,
        newValue,
        changeTimestamp: new Date().toISOString()
    };
    
    try {
        await fetch(`/tables/${HISTORY_TABLE}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(historyData)
        });
    } catch (error) {
        console.error('履歴記録エラー:', error);
    }
}

// 既存患者チェック
async function checkExistingPatient() {
    const patientId = document.getElementById('patientId').value;
    if (!patientId) return;
    
    const existingPatient = allPatients.find(p => p.patientId === patientId);
    
    if (existingPatient) {
        // 既存患者の情報を自動入力
        document.getElementById('name').value = existingPatient.name;
        document.getElementById('dateOfBirth').value = formatDateForInput(existingPatient.dateOfBirth);
        document.getElementById('disease').value = existingPatient.disease;
        document.getElementById('primaryPhysician').value = existingPatient.primaryPhysician;
        document.getElementById('team').value = existingPatient.team;
        document.getElementById('assignedNurse').value = existingPatient.assignedNurse || '';
        
        showNotification('既存患者の情報を表示しました', 'info');
    }
}

// 日付自動計算
function calculateDates() {
    const admissionDateInput = document.getElementById('admissionDate').value;
    if (!admissionDateInput) return;
    
    const admissionDate = new Date(admissionDateInput);
    
    // 90日後
    const ninetyDaysAfter = new Date(admissionDate);
    ninetyDaysAfter.setDate(ninetyDaysAfter.getDate() + 90);
    
    // 3か月後
    const threeMonthsAfter = new Date(admissionDate);
    threeMonthsAfter.setMonth(threeMonthsAfter.getMonth() + 3);
    
    // 入院期間
    const today = new Date();
    const admissionPeriod = Math.floor((today - admissionDate) / (1000 * 60 * 60 * 24));
    
    // 表示
    document.getElementById('ninetyDaysAfterDisplay').textContent = formatDate(ninetyDaysAfter.toISOString());
    document.getElementById('threeMonthsAfterDisplay').textContent = formatDate(threeMonthsAfter.toISOString());
    document.getElementById('admissionPeriodDisplay').textContent = admissionPeriod >= 0 ? `${admissionPeriod}日` : '-';
    
    document.getElementById('calculatedInfo').style.display = 'block';
}

// 入院期間計算
function calculateAdmissionPeriod(admissionDate) {
    const admission = new Date(admissionDate);
    const today = new Date();
    const days = Math.floor((today - admission) / (1000 * 60 * 60 * 24));
    return days >= 0 ? days : 0;
}

// 患者検索
function searchPatients() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const filterTeam = document.getElementById('filterTeam').value;
    const filterStatus = document.getElementById('filterStatus').value;
    
    let filteredPatients = allPatients;
    
    // チームフィルター
    if (filterTeam) {
        filteredPatients = filteredPatients.filter(p => p.team === filterTeam);
    }
    
    // ステータスフィルター
    if (filterStatus) {
        filteredPatients = filteredPatients.filter(p => p.status === filterStatus);
    }
    
    // 検索テキストフィルター
    if (searchTerm) {
        filteredPatients = filteredPatients.filter(p => 
            p.patientId.toLowerCase().includes(searchTerm) ||
            p.name.toLowerCase().includes(searchTerm)
        );
    }
    
    const container = document.getElementById('patientsList');
    
    if (filteredPatients.length === 0) {
        container.innerHTML = '<p class="text-gray-500 text-center py-4">検索結果がありません</p>';
        return;
    }
    
    // フィルタリング結果を表示
    const tempPatients = allPatients;
    allPatients = filteredPatients;
    renderPatientsList();
    allPatients = tempPatients;
}

// CSVテンプレートダウンロード
function downloadTemplate() {
    const csv = '患者番号,患者名,生年月日,病名,主治医,入院日,チーム,受け持ち看護師\nP0999,サンプル 太郎,1980-01-01,例:肺炎,田中医師,2026-02-01,1A,山田看護師\n';
    
    const bom = new Uint8Array([0xEF, 0xBB, 0xBF]);
    const blob = new Blob([bom, csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    
    link.setAttribute('href', url);
    link.setAttribute('download', '患者情報インポートテンプレート.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    showNotification('テンプレートをダウンロードしました', 'success');
}

// CSVファイル選択処理
function handleFileSelect(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            parseCSV(e.target.result);
        } catch (error) {
            console.error('CSVパースエラー:', error);
            showNotification('CSVファイルの読み込みに失敗しました', 'error');
        }
    };
    reader.readAsText(file, 'UTF-8');
}

// CSV解析
function parseCSV(csvText) {
    const lines = csvText.split('\n');
    if (lines.length < 2) {
        showNotification('CSVファイルが空です', 'error');
        return;
    }
    
    // ヘッダー行をスキップ
    const dataLines = lines.slice(1).filter(line => line.trim());
    
    importData = dataLines.map(line => {
        const columns = line.split(',').map(col => col.trim());
        
        if (columns.length < 6) {
            return null;
        }
        
        return {
            patientId: columns[0],
            name: columns[1],
            dateOfBirth: columns[2],
            disease: columns[3],
            primaryPhysician: columns[4],
            admissionDate: columns[5],
            team: columns[6] || '1A',
            assignedNurse: columns[7] || '',
            status: '入院中'
        };
    }).filter(item => item !== null);
    
    if (importData.length === 0) {
        showNotification('有効なデータがありません', 'error');
        return;
    }
    
    // プレビュー表示
    showImportPreview();
}

// インポートプレビュー表示
function showImportPreview() {
    const previewDiv = document.getElementById('importPreview');
    const contentDiv = document.getElementById('importPreviewContent');
    
    let html = `
        <p class="mb-4 text-sm text-gray-700">
            <i class="fas fa-info-circle text-blue-600 mr-2"></i>
            ${importData.length}件のデータがインポートされます。
        </p>
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500">患者番号</th>
                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500">患者名</th>
                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500">生年月日</th>
                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500">病名</th>
                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500">主治医</th>
                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500">入院日</th>
                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500">チーム</th>
                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500">受け持ちNS</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
    `;
    
    importData.forEach(patient => {
        html += `
            <tr>
                <td class="px-4 py-2 text-sm">${patient.patientId}</td>
                <td class="px-4 py-2 text-sm">${patient.name}</td>
                <td class="px-4 py-2 text-sm">${patient.dateOfBirth}</td>
                <td class="px-4 py-2 text-sm">${patient.disease}</td>
                <td class="px-4 py-2 text-sm">${patient.primaryPhysician}</td>
                <td class="px-4 py-2 text-sm">${patient.admissionDate}</td>
                <td class="px-4 py-2 text-sm">${patient.team}</td>
                <td class="px-4 py-2 text-sm">${patient.assignedNurse || '-'}</td>
            </tr>
        `;
    });
    
    html += '</tbody></table>';
    contentDiv.innerHTML = html;
    previewDiv.classList.remove('hidden');
}

// インポートキャンセル
function cancelImport() {
    importData = [];
    document.getElementById('importPreview').classList.add('hidden');
    document.getElementById('csvFileInput').value = '';
}

// インポート実行
async function executeImport() {
    if (importData.length === 0) return;
    
    let successCount = 0;
    let errorCount = 0;
    
    for (const patientData of importData) {
        // 日付の自動計算
        const admissionDate = new Date(patientData.admissionDate);
        
        const ninetyDaysAfter = new Date(admissionDate);
        ninetyDaysAfter.setDate(ninetyDaysAfter.getDate() + 90);
        
        const threeMonthsAfter = new Date(admissionDate);
        threeMonthsAfter.setMonth(threeMonthsAfter.getMonth() + 3);
        
        patientData.ninetyDaysAfter = ninetyDaysAfter.toISOString();
        patientData.threeMonthsAfter = threeMonthsAfter.toISOString();
        patientData.admissionPeriodDays = 0;
        
        try {
            const response = await fetch(`/tables/${PATIENTS_TABLE}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(patientData)
            });
            
            if (response.ok) {
                const newPatient = await response.json();
                await addHistory(newPatient.id, patientData.patientId, patientData.name, '新規登録', 'インポートによる登録', '', '');
                successCount++;
            } else {
                errorCount++;
            }
        } catch (error) {
            errorCount++;
        }
    }
    
    showNotification(`インポート完了: 成功 ${successCount}件、エラー ${errorCount}件`, 'success');
    cancelImport();
    await loadPatients();
    await loadHistory();
    check2MonthsAlert();
}

// CSVエクスポート
function exportToCSV() {
    if (allPatients.length === 0) {
        showNotification('エクスポートするデータがありません', 'warning');
        return;
    }
    
    // CSVヘッダー
    let csv = '患者番号,患者名,チーム,生年月日,病名,主治医,受け持ち看護師,入院日,退院日,90日後,3か月後,入院期間(日),ステータス\n';
    
    // データ行
    allPatients.forEach(patient => {
        const row = [
            patient.patientId,
            patient.name,
            patient.team,
            formatDate(patient.dateOfBirth),
            patient.disease,
            patient.primaryPhysician,
            patient.assignedNurse || '',
            formatDate(patient.admissionDate),
            patient.dischargeDate ? formatDate(patient.dischargeDate) : '',
            formatDate(patient.ninetyDaysAfter),
            formatDate(patient.threeMonthsAfter),
            patient.admissionPeriodDays || calculateAdmissionPeriod(patient.admissionDate),
            patient.status
        ];
        csv += row.join(',') + '\n';
    });
    
    // BOM付きUTF-8で出力
    const bom = new Uint8Array([0xEF, 0xBB, 0xBF]);
    const blob = new Blob([bom, csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    
    link.setAttribute('href', url);
    link.setAttribute('download', `患者情報_${formatDate(new Date().toISOString())}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    showNotification('CSVファイルをエクスポートしました', 'success');
}

// グラフ描画
async function renderCharts() {
    // チーム別患者数グラフ
    renderTeamChart();
    
    // 病名別患者数グラフ
    renderDiseaseChart();
    
    // 入院期間分布グラフ
    renderPeriodChart();
}

// チーム別グラフ
function renderTeamChart() {
    const ctx = document.getElementById('teamChart');
    if (!ctx) return;
    
    const team1A = allPatients.filter(p => p.status === '入院中' && p.team === '1A').length;
    const team1B = allPatients.filter(p => p.status === '入院中' && p.team === '1B').length;
    
    if (teamChart) {
        teamChart.destroy();
    }
    
    teamChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['チーム1A', 'チーム1B'],
            datasets: [{
                label: '入院患者数',
                data: [team1A, team1B],
                backgroundColor: [
                    'rgba(37, 99, 235, 0.8)',
                    'rgba(147, 51, 234, 0.8)'
                ],
                borderColor: [
                    'rgb(37, 99, 235)',
                    'rgb(147, 51, 234)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });
}

// 病名別グラフ
function renderDiseaseChart() {
    const ctx = document.getElementById('diseaseChart');
    if (!ctx) return;
    
    // 病名ごとにカウント
    const diseaseCounts = {};
    allPatients.filter(p => p.status === '入院中').forEach(patient => {
        diseaseCounts[patient.disease] = (diseaseCounts[patient.disease] || 0) + 1;
    });
    
    const diseases = Object.keys(diseaseCounts);
    const counts = Object.values(diseaseCounts);
    
    if (diseaseChart) {
        diseaseChart.destroy();
    }
    
    const colors = [
        'rgba(59, 130, 246, 0.8)',
        'rgba(16, 185, 129, 0.8)',
        'rgba(245, 158, 11, 0.8)',
        'rgba(239, 68, 68, 0.8)',
        'rgba(139, 92, 246, 0.8)',
        'rgba(236, 72, 153, 0.8)'
    ];
    
    diseaseChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: diseases,
            datasets: [{
                label: '患者数',
                data: counts,
                backgroundColor: colors.slice(0, diseases.length),
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right'
                }
            }
        }
    });
}

// 入院期間分布グラフ
function renderPeriodChart() {
    const ctx = document.getElementById('periodChart');
    if (!ctx) return;
    
    const admittedPatients = allPatients.filter(p => p.status === '入院中');
    
    // 入院期間を分類
    const periods = {
        '1週間未満': 0,
        '1週間～1か月': 0,
        '1～2か月': 0,
        '2～3か月': 0,
        '3か月以上': 0
    };
    
    admittedPatients.forEach(patient => {
        const days = calculateAdmissionPeriod(patient.admissionDate);
        if (days < 7) {
            periods['1週間未満']++;
        } else if (days < 30) {
            periods['1週間～1か月']++;
        } else if (days < 60) {
            periods['1～2か月']++;
        } else if (days < 90) {
            periods['2～3か月']++;
        } else {
            periods['3か月以上']++;
        }
    });
    
    if (periodChart) {
        periodChart.destroy();
    }
    
    periodChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: Object.keys(periods),
            datasets: [{
                label: '患者数',
                data: Object.values(periods),
                backgroundColor: 'rgba(59, 130, 246, 0.8)',
                borderColor: 'rgb(59, 130, 246)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });
}

// フォームリセット
function resetForm() {
    document.getElementById('patientForm').reset();
    document.getElementById('calculatedInfo').style.display = 'none';
}

// 日付フォーマット（表示用）
function formatDate(dateString) {
    if (!dateString) return '-';
    const date = new Date(dateString);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}/${month}/${day}`;
}

// 日時フォーマット（表示用）
function formatDateTime(dateString) {
    if (!dateString) return '-';
    const date = new Date(dateString);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    return `${year}/${month}/${day} ${hours}:${minutes}`;
}

// 日付フォーマット（input用）
function formatDateForInput(dateString) {
    if (!dateString) return '';
    const date = new Date(dateString);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

// 通知表示
function showNotification(message, type = 'info') {
    const colors = {
        success: 'bg-green-500',
        error: 'bg-red-500',
        warning: 'bg-yellow-500',
        info: 'bg-blue-500'
    };
    
    const notification = document.createElement('div');
    notification.className = `fixed top-4 right-4 ${colors[type]} text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fade-in`;
    notification.innerHTML = `
        <div class="flex items-center space-x-2">
            <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
            <span>${message}</span>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.opacity = '0';
        notification.style.transition = 'opacity 0.5s';
        setTimeout(() => notification.remove(), 500);
    }, 3000);
}

