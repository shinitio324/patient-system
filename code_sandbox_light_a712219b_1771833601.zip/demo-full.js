// ローカルストレージキー
const STORAGE_KEY = 'patientsData';
const HISTORY_KEY = 'patientsHistory';

// グローバル変数
let allPatients = [];
let allHistory = [];
let importData = [];
let teamChart = null;
let diseaseChart = null;
let periodChart = null;

// ===============================
// データ管理
// ===============================

// ローカルストレージからデータを読み込み
function loadPatientsFromStorage() {
    const data = localStorage.getItem(STORAGE_KEY);
    if (data) {
        allPatients = JSON.parse(data);
    } else {
        // 初期サンプルデータ
        allPatients = [
            {
                id: '1',
                patientId: 'P0001',
                name: '山田 太郎',
                dateOfBirth: '1950-01-15',
                disease: '肺炎',
                primaryPhysician: '田中 医師',
                admissionDate: '2025-10-01',
                dischargeDate: null,
                team: '1A',
                assignedNurse: '鈴木 NS',
                status: '入院中'
            },
            {
                id: '2',
                patientId: 'P0002',
                name: '佐藤 花子',
                dateOfBirth: '1955-05-20',
                disease: '糖尿病',
                primaryPhysician: '山田 医師',
                admissionDate: '2025-11-15',
                dischargeDate: null,
                team: '1B',
                assignedNurse: '田中 NS',
                status: '入院中'
            }
        ];
        savePatientsToStorage();
    }
}

// ローカルストレージにデータを保存
function savePatientsToStorage() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(allPatients));
}

// 履歴を読み込み
function loadHistoryFromStorage() {
    const data = localStorage.getItem(HISTORY_KEY);
    if (data) {
        allHistory = JSON.parse(data);
    }
}

// 履歴を保存
function saveHistoryToStorage() {
    localStorage.setItem(HISTORY_KEY, JSON.stringify(allHistory));
}

// 履歴を追加
function addHistory(patientId, patientName, changeType, changedFields, oldValue, newValue) {
    const historyEntry = {
        id: Date.now().toString(),
        patientId,
        patientName,
        changeType,
        changedFields,
        oldValue: JSON.stringify(oldValue),
        newValue: JSON.stringify(newValue),
        changeTimestamp: new Date().toISOString()
    };
    allHistory.unshift(historyEntry);
    saveHistoryToStorage();
}

// ===============================
// UI関数
// ===============================

// 通知表示
function showNotification(message, type = 'success') {
    const notificationArea = document.getElementById('notificationArea');
    const bgColor = type === 'success' ? 'bg-green-500' : 'bg-red-500';
    const icon = type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle';
    
    const notification = document.createElement('div');
    notification.className = `notification ${bgColor} text-white px-6 py-4 rounded-lg shadow-lg`;
    notification.innerHTML = `
        <div class="flex items-center">
            <i class="fas ${icon} text-2xl mr-3"></i>
            <span class="font-semibold">${message}</span>
        </div>
    `;
    
    notificationArea.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 3000);
}

// 日付フォーマット
function formatDate(dateString) {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleDateString('ja-JP');
}

// 日時フォーマット
function formatDateTime(dateString) {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleString('ja-JP');
}

// 入院期間計算
function calculateAdmissionPeriod(admissionDate) {
    const admission = new Date(admissionDate);
    const today = new Date();
    const diffTime = Math.abs(today - admission);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
}

// ===============================
// ダッシュボード
// ===============================

// ダッシュボード更新
function updateDashboard() {
    const totalPatients = allPatients.length;
    const admittedPatients = allPatients.filter(p => p.status === '入院中').length;
    const dischargedPatients = allPatients.filter(p => p.status === '退院').length;
    
    // 2か月経過患者を計算
    const twoMonthsAgo = new Date();
    twoMonthsAgo.setMonth(twoMonthsAgo.getMonth() - 2);
    
    const twoMonthsPatients = allPatients.filter(p => {
        if (p.status !== '入院中') return false;
        const admissionDate = new Date(p.admissionDate);
        return admissionDate <= twoMonthsAgo;
    });
    
    // チーム別カウント
    const team1A = allPatients.filter(p => p.status === '入院中' && p.team === '1A');
    const team1B = allPatients.filter(p => p.status === '入院中' && p.team === '1B');
    
    // 統計カード更新
    document.getElementById('totalPatients').textContent = totalPatients;
    document.getElementById('admittedPatients').textContent = admittedPatients;
    document.getElementById('twoMonthsPatients').textContent = twoMonthsPatients.length;
    document.getElementById('dischargedPatients').textContent = dischargedPatients;
    
    // チーム統計更新
    document.getElementById('team1ACount').textContent = team1A.length;
    document.getElementById('team1BCount').textContent = team1B.length;
    
    // チーム別患者リスト
    renderTeamList('team1AList', team1A);
    renderTeamList('team1BList', team1B);
    
    // 2か月超過アラート
    renderTwoMonthsAlert(twoMonthsPatients);
    
    // 2か月経過患者リスト
    renderTwoMonthsPatientsList(twoMonthsPatients);
}

// チーム別患者リスト表示
function renderTeamList(containerId, patients) {
    const container = document.getElementById(containerId);
    
    if (patients.length === 0) {
        container.innerHTML = '<p class="text-gray-500 text-sm">患者なし</p>';
        return;
    }
    
    let html = '<ul class="space-y-2">';
    patients.forEach(patient => {
        html += `
            <li class="text-sm">
                <span class="font-semibold">${patient.patientId}</span> - ${patient.name}
                ${patient.assignedNurse ? `<span class="text-gray-500 ml-2">(${patient.assignedNurse})</span>` : ''}
            </li>
        `;
    });
    html += '</ul>';
    container.innerHTML = html;
}

// 2か月超過アラート表示
function renderTwoMonthsAlert(patients) {
    const alertDiv = document.getElementById('twoMonthsAlert');
    const alertList = document.getElementById('twoMonthsAlertList');
    
    if (patients.length === 0) {
        alertDiv.classList.add('hidden');
        return;
    }
    
    alertDiv.classList.remove('hidden');
    
    let html = `<p class="font-semibold mb-2">${patients.length}名の患者が入院から2か月を経過しています：</p><ul class="list-disc list-inside space-y-1">`;
    patients.forEach(patient => {
        const admissionPeriod = calculateAdmissionPeriod(patient.admissionDate);
        html += `<li>${patient.patientId} - ${patient.name} (${admissionPeriod}日経過)</li>`;
    });
    html += '</ul>';
    
    alertList.innerHTML = html;
}

// 2か月経過患者リスト表示
function renderTwoMonthsPatientsList(patients) {
    const container = document.getElementById('twoMonthsPatientsList');
    
    if (patients.length === 0) {
        container.innerHTML = '<p class="text-gray-500 text-center py-4">該当する患者はいません</p>';
        return;
    }
    
    let html = `
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">患者番号</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">患者名</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">チーム</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">病名</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">入院日</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">入院期間</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">主治医</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">受け持ちNS</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
    `;
    
    patients.forEach(patient => {
        const admissionPeriod = calculateAdmissionPeriod(patient.admissionDate);
        html += `
            <tr class="hover:bg-gray-50">
                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${patient.patientId}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${patient.name}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    <span class="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${patient.team === '1A' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800'}">
                        ${patient.team}
                    </span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${patient.disease}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${formatDate(patient.admissionDate)}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${admissionPeriod}日</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${patient.primaryPhysician}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${patient.assignedNurse || '-'}</td>
            </tr>
        `;
    });
    
    html += '</tbody></table>';
    container.innerHTML = html;
}

// ===============================
// 患者一覧
// ===============================

// 患者一覧表示
function renderPatientsList() {
    const searchTerm = document.getElementById('searchInput').value;
    const teamFilter = document.getElementById('teamFilter').value;
    const statusFilter = document.getElementById('statusFilter').value;
    const container = document.getElementById('patientsList');
    
    let filteredPatients = allPatients;
    
    // 検索フィルター
    if (searchTerm) {
        filteredPatients = filteredPatients.filter(p => 
            p.patientId.toLowerCase().includes(searchTerm.toLowerCase()) ||
            p.name.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }
    
    // チームフィルター
    if (teamFilter) {
        filteredPatients = filteredPatients.filter(p => p.team === teamFilter);
    }
    
    // ステータスフィルター
    if (statusFilter) {
        filteredPatients = filteredPatients.filter(p => p.status === statusFilter);
    }
    
    if (filteredPatients.length === 0) {
        container.innerHTML = '<p class="text-gray-500 text-center py-4">該当する患者はいません</p>';
        return;
    }
    
    let html = `
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">患者番号</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">患者名</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">チーム</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">病名</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">主治医</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">受け持ちNS</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">入院日</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">ステータス</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">操作</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
    `;
    
    filteredPatients.forEach(patient => {
        const statusClass = patient.status === '入院中' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800';
        
        html += `
            <tr class="hover:bg-gray-50">
                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${patient.patientId}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${patient.name}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    <span class="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${patient.team === '1A' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800'}">
                        ${patient.team}
                    </span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${patient.disease}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${patient.primaryPhysician}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${patient.assignedNurse || '-'}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${formatDate(patient.admissionDate)}</td>
                <td class="px-6 py-4 whitespace-nowrap">
                    <span class="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${statusClass}">
                        ${patient.status}
                    </span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm space-x-2">
                    <button onclick="editPatient('${patient.id}')" class="text-blue-600 hover:text-blue-900">
                        <i class="fas fa-edit"></i> 編集
                    </button>
                    <button onclick="deletePatient('${patient.id}')" class="text-red-600 hover:text-red-900">
                        <i class="fas fa-trash"></i> 削除
                    </button>
                </td>
            </tr>
        `;
    });
    
    html += '</tbody></table>';
    container.innerHTML = html;
}

// ===============================
// 患者編集・削除
// ===============================

// 患者編集
function editPatient(id) {
    const patient = allPatients.find(p => p.id === id);
    if (!patient) return;
    
    document.getElementById('editId').value = patient.id;
    document.getElementById('editPatientId').value = patient.patientId;
    document.getElementById('editName').value = patient.name;
    document.getElementById('editDateOfBirth').value = patient.dateOfBirth;
    document.getElementById('editDisease').value = patient.disease;
    document.getElementById('editPrimaryPhysician').value = patient.primaryPhysician;
    document.getElementById('editAdmissionDate').value = patient.admissionDate;
    document.getElementById('editTeam').value = patient.team;
    document.getElementById('editAssignedNurse').value = patient.assignedNurse || '';
    document.getElementById('editStatus').value = patient.status;
    document.getElementById('editDischargeDate').value = patient.dischargeDate || '';
    
    document.getElementById('editModal').classList.remove('hidden');
}

// 編集モーダルを閉じる
function closeEditModal() {
    document.getElementById('editModal').classList.add('hidden');
}

// 患者削除
function deletePatient(id) {
    const patient = allPatients.find(p => p.id === id);
    if (!patient) return;
    
    if (!confirm(`患者「${patient.name}」の情報を削除しますか？`)) return;
    
    // 履歴に記録
    addHistory(patient.patientId, patient.name, '削除', '患者情報', patient, null);
    
    allPatients = allPatients.filter(p => p.id !== id);
    savePatientsToStorage();
    updateDashboard();
    renderPatientsList();
    renderDischargeList();
    showNotification('患者情報を削除しました', 'success');
}

// ===============================
// 退院管理
// ===============================

// 退院リスト表示
function renderDischargeList() {
    const container = document.getElementById('dischargeList');
    const admittedPatients = allPatients.filter(p => p.status === '入院中');
    
    if (admittedPatients.length === 0) {
        container.innerHTML = '<p class="text-gray-500 text-center py-4">入院中の患者はいません</p>';
        return;
    }
    
    let html = `
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">患者番号</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">患者名</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">チーム</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">病名</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">入院日</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">入院期間</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">操作</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
    `;
    
    admittedPatients.forEach(patient => {
        const admissionPeriod = calculateAdmissionPeriod(patient.admissionDate);
        
        html += `
            <tr class="hover:bg-gray-50">
                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${patient.patientId}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${patient.name}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    <span class="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${patient.team === '1A' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800'}">
                        ${patient.team}
                    </span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${patient.disease}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${formatDate(patient.admissionDate)}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${admissionPeriod}日</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm">
                    <button onclick="dischargePatient('${patient.id}')" class="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700">
                        <i class="fas fa-sign-out-alt mr-1"></i>退院処理
                    </button>
                </td>
            </tr>
        `;
    });
    
    html += '</tbody></table>';
    container.innerHTML = html;
}

// 退院処理
function dischargePatient(id) {
    const patient = allPatients.find(p => p.id === id);
    if (!patient) return;
    
    if (!confirm(`患者「${patient.name}」を退院処理しますか？`)) return;
    
    const oldStatus = patient.status;
    const today = new Date().toISOString().split('T')[0];
    
    patient.status = '退院';
    patient.dischargeDate = today;
    
    // 履歴に記録
    addHistory(patient.patientId, patient.name, '退院処理', 'ステータス', oldStatus, '退院');
    
    savePatientsToStorage();
    updateDashboard();
    renderDischargeList();
    renderPatientsList();
    showNotification('退院処理が完了しました', 'success');
}

// ===============================
// 履歴管理
// ===============================

// 履歴表示
function renderHistoryList() {
    const searchTerm = document.getElementById('historySearch').value;
    const container = document.getElementById('historyList');
    
    let filteredHistory = allHistory;
    
    if (searchTerm) {
        filteredHistory = filteredHistory.filter(h => 
            h.patientId.toLowerCase().includes(searchTerm.toLowerCase()) ||
            h.patientName.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }
    
    if (filteredHistory.length === 0) {
        container.innerHTML = '<p class="text-gray-500 text-center py-4">履歴データはありません</p>';
        return;
    }
    
    let html = '';
    filteredHistory.forEach(record => {
        const changeTypeClass = {
            '新規登録': 'bg-green-100 text-green-800',
            '情報更新': 'bg-blue-100 text-blue-800',
            '退院処理': 'bg-purple-100 text-purple-800',
            '削除': 'bg-red-100 text-red-800'
        }[record.changeType] || 'bg-gray-100 text-gray-800';
        
        html += `
            <div class="border border-gray-200 rounded-lg p-4">
                <div class="flex items-start justify-between mb-2">
                    <div>
                        <span class="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${changeTypeClass}">
                            ${record.changeType}
                        </span>
                        <span class="ml-2 font-semibold">${record.patientId} - ${record.patientName}</span>
                    </div>
                    <span class="text-sm text-gray-500">${formatDateTime(record.changeTimestamp)}</span>
                </div>
                ${record.changedFields ? `
                    <div class="text-sm text-gray-700 mt-2">
                        <span class="font-semibold">変更内容:</span> ${record.changedFields}
                    </div>
                ` : ''}
            </div>
        `;
    });
    
    container.innerHTML = html;
}

// ===============================
// CSV一括インポート
// ===============================

// テンプレートダウンロード
function downloadTemplate() {
    const template = 'patientId,name,dateOfBirth,disease,primaryPhysician,admissionDate,team,assignedNurse\nP0001,山田 太郎,1950-01-15,肺炎,田中 医師,2026-02-01,1A,鈴木 NS\nP0002,佐藤 花子,1955-05-20,糖尿病,山田 医師,2026-02-01,1B,田中 NS\n';
    
    const blob = new Blob(['\ufeff' + template], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = '患者情報インポートテンプレート.csv';
    link.click();
    
    showNotification('テンプレートをダウンロードしました', 'success');
}

// ファイル選択処理
function handleFileSelect(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(e) {
        const text = e.target.result;
        parseCSV(text);
    };
    reader.readAsText(file);
}

// CSV解析
function parseCSV(text) {
    const lines = text.split('\n').filter(line => line.trim());
    const headers = lines[0].split(',');
    
    importData = [];
    for (let i = 1; i < lines.length; i++) {
        const values = lines[i].split(',');
        const patient = {};
        headers.forEach((header, index) => {
            patient[header.trim()] = values[index]?.trim() || '';
        });
        importData.push(patient);
    }
    
    showImportPreview();
}

// インポートプレビュー表示
function showImportPreview() {
    const previewDiv = document.getElementById('importPreview');
    const contentDiv = document.getElementById('importPreviewContent');
    
    let html = `
        <p class="mb-4 font-semibold">${importData.length}件のデータをインポート準備完了</p>
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">患者番号</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">患者名</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">チーム</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">病名</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
    `;
    
    importData.forEach(patient => {
        html += `
            <tr>
                <td class="px-6 py-4 whitespace-nowrap text-sm">${patient.patientId}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm">${patient.name}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm">${patient.team}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm">${patient.disease}</td>
            </tr>
        `;
    });
    
    html += '</tbody></table>';
    contentDiv.innerHTML = html;
    previewDiv.classList.remove('hidden');
}

// インポート実行
function executeImport() {
    let successCount = 0;
    
    importData.forEach(data => {
        const newPatient = {
            id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
            patientId: data.patientId,
            name: data.name,
            dateOfBirth: data.dateOfBirth,
            disease: data.disease,
            primaryPhysician: data.primaryPhysician,
            admissionDate: data.admissionDate,
            dischargeDate: null,
            team: data.team,
            assignedNurse: data.assignedNurse || '',
            status: '入院中'
        };
        
        allPatients.push(newPatient);
        addHistory(newPatient.patientId, newPatient.name, '新規登録', 'CSVインポート', null, newPatient);
        successCount++;
    });
    
    savePatientsToStorage();
    updateDashboard();
    renderPatientsList();
    
    document.getElementById('importPreview').classList.add('hidden');
    document.getElementById('csvFileInput').value = '';
    importData = [];
    
    showNotification(`${successCount}件の患者情報をインポートしました`, 'success');
}

// ===============================
// 統計グラフ
// ===============================

// グラフ描画
function renderCharts() {
    renderTeamChart();
    renderDiseaseChart();
    renderPeriodChart();
}

// チーム別グラフ
function renderTeamChart() {
    const ctx = document.getElementById('teamChart');
    if (!ctx) return;
    
    const team1A = allPatients.filter(p => p.status === '入院中' && p.team === '1A').length;
    const team1B = allPatients.filter(p => p.status === '入院中' && p.team === '1B').length;
    
    if (teamChart) teamChart.destroy();
    
    teamChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['チーム1A', 'チーム1B'],
            datasets: [{
                label: '入院患者数',
                data: [team1A, team1B],
                backgroundColor: ['rgba(59, 130, 246, 0.8)', 'rgba(168, 85, 247, 0.8)']
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { stepSize: 1 }
                }
            }
        }
    });
}

// 病名別グラフ
function renderDiseaseChart() {
    const ctx = document.getElementById('diseaseChart');
    if (!ctx) return;
    
    const diseaseCount = {};
    allPatients.forEach(p => {
        diseaseCount[p.disease] = (diseaseCount[p.disease] || 0) + 1;
    });
    
    const labels = Object.keys(diseaseCount);
    const data = Object.values(diseaseCount);
    
    if (diseaseChart) diseaseChart.destroy();
    
    diseaseChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: labels,
            datasets: [{
                data: data,
                backgroundColor: [
                    'rgba(59, 130, 246, 0.8)',
                    'rgba(16, 185, 129, 0.8)',
                    'rgba(251, 191, 36, 0.8)',
                    'rgba(239, 68, 68, 0.8)',
                    'rgba(168, 85, 247, 0.8)',
                    'rgba(236, 72, 153, 0.8)'
                ]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false
        }
    });
}

// 入院期間分布グラフ
function renderPeriodChart() {
    const ctx = document.getElementById('periodChart');
    if (!ctx) return;
    
    const periods = {
        '1週間未満': 0,
        '1週間〜1か月': 0,
        '1〜2か月': 0,
        '2〜3か月': 0,
        '3か月以上': 0
    };
    
    allPatients.filter(p => p.status === '入院中').forEach(p => {
        const days = calculateAdmissionPeriod(p.admissionDate);
        if (days < 7) periods['1週間未満']++;
        else if (days < 30) periods['1週間〜1か月']++;
        else if (days < 60) periods['1〜2か月']++;
        else if (days < 90) periods['2〜3か月']++;
        else periods['3か月以上']++;
    });
    
    if (periodChart) periodChart.destroy();
    
    periodChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: Object.keys(periods),
            datasets: [{
                label: '患者数',
                data: Object.values(periods),
                backgroundColor: 'rgba(59, 130, 246, 0.8)'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { stepSize: 1 }
                }
            }
        }
    });
}

// ===============================
// CSVエクスポート
// ===============================

// CSVエクスポート
function exportCSV() {
    const headers = ['患者番号', '患者名', 'チーム', '生年月日', '病名', '主治医', '受け持ちNS', '入院日', '退院日', 'ステータス', '入院期間(日)'];
    let csv = headers.join(',') + '\n';
    
    allPatients.forEach(patient => {
        const admissionPeriod = calculateAdmissionPeriod(patient.admissionDate);
        const row = [
            patient.patientId,
            patient.name,
            patient.team,
            patient.dateOfBirth,
            patient.disease,
            patient.primaryPhysician,
            patient.assignedNurse || '',
            patient.admissionDate,
            patient.dischargeDate || '',
            patient.status,
            admissionPeriod
        ];
        csv += row.join(',') + '\n';
    });
    
    const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `患者情報_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    
    showNotification('CSVファイルをエクスポートしました', 'success');
}

// ===============================
// フォーム処理
// ===============================

// フォームリセット
function resetForm() {
    document.getElementById('patientForm').reset();
    showNotification('フォームをリセットしました', 'success');
}

// ===============================
// 初期化
// ===============================

// ページ読み込み時の初期化
document.addEventListener('DOMContentLoaded', () => {
    // データ読み込み
    loadPatientsFromStorage();
    loadHistoryFromStorage();
    
    // 初期表示
    updateDashboard();
    renderPatientsList();
    renderDischargeList();
    renderHistoryList();
    
    // タブ切り替え
    document.querySelectorAll('.tab-btn').forEach(button => {
        button.addEventListener('click', () => {
            const targetTab = button.getAttribute('data-tab');
            
            // タブボタンのスタイル更新
            document.querySelectorAll('.tab-btn').forEach(btn => {
                btn.classList.remove('active', 'text-blue-600', 'border-b-2', 'border-blue-600');
                btn.classList.add('text-gray-600');
            });
            button.classList.add('active', 'text-blue-600', 'border-b-2', 'border-blue-600');
            button.classList.remove('text-gray-600');
            
            // タブコンテンツの表示切替
            document.querySelectorAll('.tab-content').forEach(content => {
                content.classList.remove('active');
            });
            document.getElementById(`${targetTab}-tab`).classList.add('active');
            
            // グラフタブの場合は描画
            if (targetTab === 'charts') {
                renderCharts();
            }
        });
    });
    
    // 患者登録フォーム送信
    document.getElementById('patientForm').addEventListener('submit', (e) => {
        e.preventDefault();
        
        const newPatient = {
            id: Date.now().toString(),
            patientId: document.getElementById('patientId').value,
            name: document.getElementById('name').value,
            dateOfBirth: document.getElementById('dateOfBirth').value,
            disease: document.getElementById('disease').value,
            primaryPhysician: document.getElementById('primaryPhysician').value,
            admissionDate: document.getElementById('admissionDate').value,
            dischargeDate: null,
            team: document.getElementById('team').value,
            assignedNurse: document.getElementById('assignedNurse').value || '',
            status: '入院中'
        };
        
        allPatients.push(newPatient);
        addHistory(newPatient.patientId, newPatient.name, '新規登録', '患者情報', null, newPatient);
        savePatientsToStorage();
        updateDashboard();
        renderPatientsList();
        renderDischargeList();
        resetForm();
        showNotification('患者情報を登録しました', 'success');
    });
    
    // 編集フォーム送信
    document.getElementById('editForm').addEventListener('submit', (e) => {
        e.preventDefault();
        
        const id = document.getElementById('editId').value;
        const patient = allPatients.find(p => p.id === id);
        if (!patient) return;
        
        const oldPatient = {...patient};
        
        patient.patientId = document.getElementById('editPatientId').value;
        patient.name = document.getElementById('editName').value;
        patient.dateOfBirth = document.getElementById('editDateOfBirth').value;
        patient.disease = document.getElementById('editDisease').value;
        patient.primaryPhysician = document.getElementById('editPrimaryPhysician').value;
        patient.admissionDate = document.getElementById('editAdmissionDate').value;
        patient.team = document.getElementById('editTeam').value;
        patient.assignedNurse = document.getElementById('editAssignedNurse').value || '';
        patient.status = document.getElementById('editStatus').value;
        patient.dischargeDate = document.getElementById('editDischargeDate').value || null;
        
        addHistory(patient.patientId, patient.name, '情報更新', '患者情報', oldPatient, patient);
        savePatientsToStorage();
        updateDashboard();
        renderPatientsList();
        renderDischargeList();
        closeEditModal();
        showNotification('患者情報を更新しました', 'success');
    });
    
    // 検索フィルター
    document.getElementById('searchInput').addEventListener('input', renderPatientsList);
    document.getElementById('teamFilter').addEventListener('change', renderPatientsList);
    document.getElementById('statusFilter').addEventListener('change', renderPatientsList);
    document.getElementById('historySearch').addEventListener('input', renderHistoryList);
});
