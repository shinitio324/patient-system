# 患者情報管理システム - 技術仕様書

## システムアーキテクチャ

### 概要

本システムは、静的WebアプリケーションとしてRESTful Table APIを使用してデータ管理を行います。

### 技術スタック

| カテゴリ | 技術 | バージョン |
|---------|------|-----------|
| フロントエンド | HTML5 | - |
| スタイル | Tailwind CSS | 3.x (CDN) |
| JavaScript | ES6+ | - |
| アイコン | Font Awesome | 6.4.0 |
| フォント | Noto Sans JP | - |
| データベースAPI | RESTful Table API | - |

## データベース設計

### テーブル: patients

#### スキーマ定義

```javascript
{
  "name": "patients",
  "fields": [
    {
      "name": "id",
      "type": "text",
      "description": "患者ID（一意識別子）"
    },
    {
      "name": "patientId",
      "type": "text",
      "description": "患者番号"
    },
    {
      "name": "name",
      "type": "text",
      "description": "患者名"
    },
    {
      "name": "dateOfBirth",
      "type": "datetime",
      "description": "生年月日"
    },
    {
      "name": "disease",
      "type": "text",
      "description": "病名"
    },
    {
      "name": "primaryPhysician",
      "type": "text",
      "description": "主治医"
    },
    {
      "name": "admissionDate",
      "type": "datetime",
      "description": "入院日"
    },
    {
      "name": "dischargeDate",
      "type": "datetime",
      "description": "退院日"
    },
    {
      "name": "ninetyDaysAfter",
      "type": "datetime",
      "description": "90日後の日付"
    },
    {
      "name": "threeMonthsAfter",
      "type": "datetime",
      "description": "3か月後の日付"
    },
    {
      "name": "admissionPeriodDays",
      "type": "number",
      "description": "入院期間（日数）"
    },
    {
      "name": "status",
      "type": "text",
      "description": "患者ステータス（入院中/退院）"
    }
  ]
}
```

#### インデックス

システムフィールドにより自動的に以下のインデックスが作成されます：
- `id` (PRIMARY KEY)
- `created_at`
- `updated_at`

#### 制約

- `id`: 必須、一意
- `patientId`: 必須
- `name`: 必須
- `admissionDate`: 必須
- `status`: 必須（デフォルト: "入院中"）

## API仕様

### RESTful Table API エンドポイント

#### 1. 患者一覧取得

```
GET /tables/patients?limit=1000
```

**レスポンス:**
```json
{
  "data": [
    {
      "id": "uuid",
      "patientId": "P0001",
      "name": "山田 太郎",
      "dateOfBirth": "1955-03-15T00:00:00.000Z",
      "disease": "肺炎",
      "primaryPhysician": "田中 一郎",
      "admissionDate": "2023-09-01T00:00:00.000Z",
      "dischargeDate": null,
      "ninetyDaysAfter": "2023-11-30T00:00:00.000Z",
      "threeMonthsAfter": "2023-12-01T00:00:00.000Z",
      "admissionPeriodDays": 500,
      "status": "入院中",
      "created_at": 1234567890000,
      "updated_at": 1234567890000
    }
  ],
  "total": 1,
  "page": 1,
  "limit": 1000
}
```

#### 2. 患者登録

```
POST /tables/patients
Content-Type: application/json
```

**リクエストボディ:**
```json
{
  "patientId": "P0001",
  "name": "山田 太郎",
  "dateOfBirth": "1955-03-15T00:00:00.000Z",
  "disease": "肺炎",
  "primaryPhysician": "田中 一郎",
  "admissionDate": "2023-09-01T00:00:00.000Z",
  "ninetyDaysAfter": "2023-11-30T00:00:00.000Z",
  "threeMonthsAfter": "2023-12-01T00:00:00.000Z",
  "admissionPeriodDays": 0,
  "status": "入院中"
}
```

#### 3. 患者情報更新

```
PUT /tables/patients/{id}
Content-Type: application/json
```

**リクエストボディ:**
```json
{
  "patientId": "P0001",
  "name": "山田 太郎",
  "dateOfBirth": "1955-03-15T00:00:00.000Z",
  "disease": "肺炎",
  "primaryPhysician": "田中 一郎",
  "admissionDate": "2023-09-01T00:00:00.000Z",
  "dischargeDate": "2024-01-01T00:00:00.000Z",
  "ninetyDaysAfter": "2023-11-30T00:00:00.000Z",
  "threeMonthsAfter": "2023-12-01T00:00:00.000Z",
  "admissionPeriodDays": 122,
  "status": "退院"
}
```

#### 4. 患者削除

```
DELETE /tables/patients/{id}
```

## フロントエンド設計

### ファイル構成

```
/
├── index.html              # メインHTML
├── js/
│   └── app.js             # アプリケーションロジック
├── docs/
│   ├── user-guide.md      # 使用ガイド
│   └── technical-spec.md  # 技術仕様書
└── README.md              # プロジェクト概要
```

### 主要関数

#### データ管理

- `loadPatients()`: 患者データの読み込み
- `updateDashboard()`: ダッシュボード統計の更新
- `renderPatientsList()`: 患者一覧の描画
- `renderDischargeList()`: 退院管理リストの描画

#### 患者操作

- `handlePatientFormSubmit(event)`: 患者登録処理
- `handleEditFormSubmit(event)`: 患者更新処理
- `editPatient(id)`: 患者編集モーダル表示
- `deletePatient(id)`: 患者削除処理
- `dischargePatient(id)`: 退院処理

#### ユーティリティ

- `calculateDates()`: 日付自動計算
- `calculateAdmissionPeriod(admissionDate)`: 入院期間計算
- `checkExistingPatient()`: 重複入力防止チェック
- `searchPatients()`: 患者検索
- `exportToCSV()`: CSVエクスポート
- `formatDate(dateString)`: 日付フォーマット
- `showNotification(message, type)`: 通知表示

## 計算ロジック

### 90日後の計算

```javascript
const admissionDate = new Date(admissionDateInput);
const ninetyDaysAfter = new Date(admissionDate);
ninetyDaysAfter.setDate(ninetyDaysAfter.getDate() + 90);
```

### 3か月後の計算

```javascript
const admissionDate = new Date(admissionDateInput);
const threeMonthsAfter = new Date(admissionDate);
threeMonthsAfter.setMonth(threeMonthsAfter.getMonth() + 3);
```

### 入院期間の計算

```javascript
function calculateAdmissionPeriod(admissionDate) {
    const admission = new Date(admissionDate);
    const today = new Date();
    const days = Math.floor((today - admission) / (1000 * 60 * 60 * 24));
    return days >= 0 ? days : 0;
}
```

### 3か月経過患者の判定

```javascript
const today = new Date();
const threeMonthsAgo = new Date();
threeMonthsAgo.setMonth(threeMonthsAgo.getMonth() - 3);

const threeMonthsPatients = allPatients.filter(p => {
    if (p.status !== '入院中') return false;
    const admissionDate = new Date(p.admissionDate);
    return admissionDate <= threeMonthsAgo;
});
```

## UI/UX設計

### カラースキーム

| 要素 | カラーコード | 用途 |
|-----|------------|------|
| プライマリ | `#2563eb` (blue-600) | ヘッダー、ボタン |
| セカンダリ | `#10b981` (green-600) | 成功表示 |
| 警告 | `#f59e0b` (orange-600) | 注意喚起 |
| エラー | `#ef4444` (red-600) | エラー表示 |
| 背景 | `#f3f4f6` (gray-100) | 背景色 |

### レスポンシブブレークポイント

Tailwind CSSのデフォルトブレークポイントを使用：

| サイズ | ブレークポイント |
|-------|--------------|
| sm | 640px |
| md | 768px |
| lg | 1024px |
| xl | 1280px |

### アクセシビリティ

- セマンティックHTML使用
- キーボードナビゲーション対応
- 適切なコントラスト比
- Font Awesomeアイコンによる視覚的補助

## セキュリティ考慮事項

### データ保護

- RESTful Table APIによる安全なデータ管理
- クライアント側バリデーション実装
- XSS対策（innerHTMLの安全な使用）

### 入力検証

- 必須フィールドのバリデーション
- 日付形式の検証
- 患者番号の重複チェック

## パフォーマンス最適化

### データローディング

- 初期ロード時に全患者データを取得（limit=1000）
- クライアント側でのフィルタリングとソート
- 編集・削除後の差分更新

### CSS/JS最適化

- CDN利用による高速読み込み
- 必要最小限のJavaScriptコード
- Tailwind CSSによる最適化されたCSS

## ブラウザ互換性

### 対応ブラウザ

- Google Chrome 90+
- Mozilla Firefox 88+
- Microsoft Edge 90+
- Safari 14+

### 必要なJavaScript機能

- ES6+ (async/await, arrow functions, etc.)
- Fetch API
- Date API
- LocalStorage (将来の拡張用)

## デプロイメント

### 静的ホスティング

本システムは静的Webサイトとして動作するため、以下のプラットフォームにデプロイ可能：

- Netlify
- Vercel
- GitHub Pages
- AWS S3 + CloudFront
- Azure Static Web Apps

### 環境変数

現在のバージョンでは環境変数は不要です。

## テスト戦略

### 手動テスト項目

1. **患者登録**
   - 正常系: 全項目入力して登録
   - 異常系: 必須項目未入力

2. **患者一覧**
   - 全患者表示
   - 検索機能

3. **患者編集**
   - 情報更新
   - ステータス変更

4. **退院処理**
   - 退院日記録
   - ステータス更新

5. **CSVエクスポート**
   - データ出力
   - 文字コード確認

## 今後の拡張予定

### フェーズ2

- チーム分け機能
- 受け持ち看護師の記録
- アラート機能

### フェーズ3

- 患者履歴管理
- 一括インポート機能
- グラフ表示

### フェーズ4

- ユーザー認証
- 権限管理
- 監査ログ

---

**ドキュメントバージョン**: 1.0.0  
**最終更新日**: 2026年2月14日
