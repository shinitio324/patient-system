// データ移行スクリプト
// 既存のpatientsテーブルから新しいpatients_v2テーブルにデータを移行

async function migrateData() {
    try {
        // 既存データを取得
        const response = await fetch('/tables/patients?limit=1000');
        const data = await response.json();
        const oldPatients = data.data || [];
        
        console.log(`移行対象: ${oldPatients.length}件`);
        
        // 新しいテーブルに移行
        for (const patient of oldPatients) {
            const newPatient = {
                patientId: patient.patientId,
                name: patient.name,
                dateOfBirth: patient.dateOfBirth,
                disease: patient.disease,
                primaryPhysician: patient.primaryPhysician,
                admissionDate: patient.admissionDate,
                dischargeDate: patient.dischargeDate,
                ninetyDaysAfter: patient.ninetyDaysAfter,
                threeMonthsAfter: patient.threeMonthsAfter,
                admissionPeriodDays: patient.admissionPeriodDays,
                status: patient.status,
                team: '1A', // デフォルトチーム
                assignedNurse: '' // 未割り当て
            };
            
            const createResponse = await fetch('/tables/patients_v2', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(newPatient)
            });
            
            if (createResponse.ok) {
                console.log(`移行完了: ${patient.patientId} - ${patient.name}`);
            }
        }
        
        console.log('データ移行が完了しました');
    } catch (error) {
        console.error('データ移行エラー:', error);
    }
}

// 実行
migrateData();
