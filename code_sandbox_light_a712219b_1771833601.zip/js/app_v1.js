// グローバル変数
let allPatients = [];
let currentEditId = null;

// 初期化
document.addEventListener('DOMContentLoaded', async () => {
    // タブ切り替え
    setupTabNavigation();
    
    // フォーム送信イベント
    document.getElementById('patientForm').addEventListener('submit', handlePatientFormSubmit);
    document.getElementById('editForm').addEventListener('submit', handleEditFormSubmit);
    
    // 入院日変更時の自動計算
    document.getElementById('admissionDate').addEventListener('change', calculateDates);
    
    // 患者番号入力時の自動検索
    document.getElementById('patientId').addEventListener('blur', checkExistingPatient);
    
    // 初期データ読み込み
    await loadPatients();
    updateDashboard();
});

// タブナビゲーション設定
function setupTabNavigation() {
    const tabButtons = document.querySelectorAll('.tab-btn');
    
    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            const targetTab = button.getAttribute('data-tab');
            
            // すべてのタブボタンとコンテンツを非アクティブに
            tabButtons.forEach(btn => {
                btn.classList.remove('active', 'text-blue-600', 'border-b-2', 'border-blue-600');
                btn.classList.add('text-gray-600');
            });
            
            document.querySelectorAll('.tab-content').forEach(content => {
                content.classList.add('hidden');
            });
            
            // クリックされたタブをアクティブに
            button.classList.add('active', 'text-blue-600', 'border-b-2', 'border-blue-600');
            button.classList.remove('text-gray-600');
            document.getElementById(`${targetTab}-tab`).classList.remove('hidden');
        });
    });
}

// 患者データ読み込み
async function loadPatients() {
    try {
        const response = await fetch('/tables/patients?limit=1000');
        const data = await response.json();
        allPatients = data.data || [];
        
        updateDashboard();
        renderPatientsList();
        renderDischargeList();
    } catch (error) {
        console.error('患者データの読み込みに失敗しました:', error);
        showNotification('患者データの読み込みに失敗しました', 'error');
    }
}

// ダッシュボード更新
function updateDashboard() {
    const totalPatients = allPatients.length;
    const admittedPatients = allPatients.filter(p => p.status === '入院中').length;
    const dischargedPatients = allPatients.filter(p => p.status === '退院').length;
    
    // 3か月経過患者を計算
    const today = new Date();
    const threeMonthsAgo = new Date();
    threeMonthsAgo.setMonth(threeMonthsAgo.getMonth() - 3);
    
    const threeMonthsPatients = allPatients.filter(p => {
        if (p.status !== '入院中') return false;
        const admissionDate = new Date(p.admissionDate);
        return admissionDate <= threeMonthsAgo;
    });
    
    // 統計カード更新
    document.getElementById('totalPatients').textContent = totalPatients;
    document.getElementById('admittedPatients').textContent = admittedPatients;
    document.getElementById('threeMonthsPatients').textContent = threeMonthsPatients.length;
    document.getElementById('dischargedPatients').textContent = dischargedPatients;
    
    // 3か月経過患者リスト表示
    renderThreeMonthsPatients(threeMonthsPatients);
}

// 3か月経過患者リスト表示
function renderThreeMonthsPatients(patients) {
    const container = document.getElementById('threeMonthsPatientsList');
    
    if (patients.length === 0) {
        container.innerHTML = '<p class="text-gray-500 text-center py-4">該当する患者はいません</p>';
        return;
    }
    
    let html = `
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">患者番号</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">患者名</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">病名</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">入院日</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">入院期間</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">主治医</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
    `;
    
    patients.forEach(patient => {
        const admissionPeriod = calculateAdmissionPeriod(patient.admissionDate);
        html += `
            <tr class="hover:bg-gray-50">
                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${patient.patientId}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${patient.name}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${patient.disease}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${formatDate(patient.admissionDate)}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${admissionPeriod}日</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${patient.primaryPhysician}</td>
            </tr>
        `;
    });
    
    html += '</tbody></table>';
    container.innerHTML = html;
}

// 患者一覧表示
function renderPatientsList() {
    const container = document.getElementById('patientsList');
    
    if (allPatients.length === 0) {
        container.innerHTML = '<p class="text-gray-500 text-center py-4">登録された患者はいません</p>';
        return;
    }
    
    let html = `
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">患者番号</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">患者名</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">生年月日</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">病名</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">主治医</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">入院日</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ステータス</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">操作</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
    `;
    
    allPatients.forEach(patient => {
        const statusClass = patient.status === '入院中' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800';
        html += `
            <tr class="hover:bg-gray-50">
                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${patient.patientId}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${patient.name}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${formatDate(patient.dateOfBirth)}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${patient.disease}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${patient.primaryPhysician}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${formatDate(patient.admissionDate)}</td>
                <td class="px-6 py-4 whitespace-nowrap">
                    <span class="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${statusClass}">
                        ${patient.status}
                    </span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                    <button onclick="editPatient('${patient.id}')" class="text-blue-600 hover:text-blue-900">
                        <i class="fas fa-edit"></i> 編集
                    </button>
                    <button onclick="deletePatient('${patient.id}')" class="text-red-600 hover:text-red-900">
                        <i class="fas fa-trash"></i> 削除
                    </button>
                </td>
            </tr>
        `;
    });
    
    html += '</tbody></table>';
    container.innerHTML = html;
}

// 退院管理リスト表示
function renderDischargeList() {
    const container = document.getElementById('dischargeList');
    const admittedPatients = allPatients.filter(p => p.status === '入院中');
    
    if (admittedPatients.length === 0) {
        container.innerHTML = '<p class="text-gray-500 text-center py-4">入院中の患者はいません</p>';
        return;
    }
    
    let html = `
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">患者番号</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">患者名</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">入院日</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">入院期間</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">90日後</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">3か月後</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">操作</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
    `;
    
    admittedPatients.forEach(patient => {
        const admissionPeriod = calculateAdmissionPeriod(patient.admissionDate);
        html += `
            <tr class="hover:bg-gray-50">
                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${patient.patientId}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${patient.name}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${formatDate(patient.admissionDate)}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${admissionPeriod}日</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${formatDate(patient.ninetyDaysAfter)}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${formatDate(patient.threeMonthsAfter)}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <button onclick="dischargePatient('${patient.id}')" class="text-green-600 hover:text-green-900">
                        <i class="fas fa-sign-out-alt"></i> 退院処理
                    </button>
                </td>
            </tr>
        `;
    });
    
    html += '</tbody></table>';
    container.innerHTML = html;
}

// 患者フォーム送信処理
async function handlePatientFormSubmit(event) {
    event.preventDefault();
    
    const patientData = {
        patientId: document.getElementById('patientId').value,
        name: document.getElementById('name').value,
        dateOfBirth: document.getElementById('dateOfBirth').value,
        disease: document.getElementById('disease').value,
        primaryPhysician: document.getElementById('primaryPhysician').value,
        admissionDate: document.getElementById('admissionDate').value,
        status: '入院中'
    };
    
    // 日付の自動計算
    const admissionDate = new Date(patientData.admissionDate);
    
    // 90日後
    const ninetyDaysAfter = new Date(admissionDate);
    ninetyDaysAfter.setDate(ninetyDaysAfter.getDate() + 90);
    
    // 3か月後
    const threeMonthsAfter = new Date(admissionDate);
    threeMonthsAfter.setMonth(threeMonthsAfter.getMonth() + 3);
    
    patientData.ninetyDaysAfter = ninetyDaysAfter.toISOString();
    patientData.threeMonthsAfter = threeMonthsAfter.toISOString();
    patientData.admissionPeriodDays = 0;
    
    try {
        const response = await fetch('/tables/patients', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(patientData)
        });
        
        if (response.ok) {
            showNotification('患者情報を登録しました', 'success');
            resetForm();
            await loadPatients();
        } else {
            throw new Error('登録に失敗しました');
        }
    } catch (error) {
        console.error('患者登録エラー:', error);
        showNotification('患者情報の登録に失敗しました', 'error');
    }
}

// 編集フォーム送信処理
async function handleEditFormSubmit(event) {
    event.preventDefault();
    
    const id = document.getElementById('editId').value;
    const patientData = {
        patientId: document.getElementById('editPatientId').value,
        name: document.getElementById('editName').value,
        dateOfBirth: document.getElementById('editDateOfBirth').value,
        disease: document.getElementById('editDisease').value,
        primaryPhysician: document.getElementById('editPrimaryPhysician').value,
        admissionDate: document.getElementById('editAdmissionDate').value,
        dischargeDate: document.getElementById('editDischargeDate').value || null,
        status: document.getElementById('editStatus').value
    };
    
    // 日付の再計算
    const admissionDate = new Date(patientData.admissionDate);
    const ninetyDaysAfter = new Date(admissionDate);
    ninetyDaysAfter.setDate(ninetyDaysAfter.getDate() + 90);
    
    const threeMonthsAfter = new Date(admissionDate);
    threeMonthsAfter.setMonth(threeMonthsAfter.getMonth() + 3);
    
    patientData.ninetyDaysAfter = ninetyDaysAfter.toISOString();
    patientData.threeMonthsAfter = threeMonthsAfter.toISOString();
    patientData.admissionPeriodDays = calculateAdmissionPeriod(patientData.admissionDate);
    
    try {
        const response = await fetch(`/tables/patients/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(patientData)
        });
        
        if (response.ok) {
            showNotification('患者情報を更新しました', 'success');
            closeEditModal();
            await loadPatients();
        } else {
            throw new Error('更新に失敗しました');
        }
    } catch (error) {
        console.error('患者更新エラー:', error);
        showNotification('患者情報の更新に失敗しました', 'error');
    }
}

// 患者編集
function editPatient(id) {
    const patient = allPatients.find(p => p.id === id);
    if (!patient) return;
    
    document.getElementById('editId').value = patient.id;
    document.getElementById('editPatientId').value = patient.patientId;
    document.getElementById('editName').value = patient.name;
    document.getElementById('editDateOfBirth').value = formatDateForInput(patient.dateOfBirth);
    document.getElementById('editDisease').value = patient.disease;
    document.getElementById('editPrimaryPhysician').value = patient.primaryPhysician;
    document.getElementById('editAdmissionDate').value = formatDateForInput(patient.admissionDate);
    document.getElementById('editDischargeDate').value = patient.dischargeDate ? formatDateForInput(patient.dischargeDate) : '';
    document.getElementById('editStatus').value = patient.status;
    
    document.getElementById('editModal').classList.remove('hidden');
    document.getElementById('editModal').classList.add('flex');
}

// 編集モーダルを閉じる
function closeEditModal() {
    document.getElementById('editModal').classList.add('hidden');
    document.getElementById('editModal').classList.remove('flex');
}

// 患者削除
async function deletePatient(id) {
    if (!confirm('この患者情報を削除してもよろしいですか？')) {
        return;
    }
    
    try {
        const response = await fetch(`/tables/patients/${id}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            showNotification('患者情報を削除しました', 'success');
            await loadPatients();
        } else {
            throw new Error('削除に失敗しました');
        }
    } catch (error) {
        console.error('患者削除エラー:', error);
        showNotification('患者情報の削除に失敗しました', 'error');
    }
}

// 退院処理
async function dischargePatient(id) {
    if (!confirm('この患者を退院処理してもよろしいですか？')) {
        return;
    }
    
    const patient = allPatients.find(p => p.id === id);
    if (!patient) return;
    
    const today = new Date().toISOString();
    patient.status = '退院';
    patient.dischargeDate = today;
    
    try {
        const response = await fetch(`/tables/patients/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(patient)
        });
        
        if (response.ok) {
            showNotification('退院処理を完了しました', 'success');
            await loadPatients();
        } else {
            throw new Error('退院処理に失敗しました');
        }
    } catch (error) {
        console.error('退院処理エラー:', error);
        showNotification('退院処理に失敗しました', 'error');
    }
}

// 既存患者チェック
async function checkExistingPatient() {
    const patientId = document.getElementById('patientId').value;
    if (!patientId) return;
    
    const existingPatient = allPatients.find(p => p.patientId === patientId);
    
    if (existingPatient) {
        // 既存患者の情報を自動入力
        document.getElementById('name').value = existingPatient.name;
        document.getElementById('dateOfBirth').value = formatDateForInput(existingPatient.dateOfBirth);
        document.getElementById('disease').value = existingPatient.disease;
        document.getElementById('primaryPhysician').value = existingPatient.primaryPhysician;
        
        showNotification('既存患者の情報を表示しました', 'info');
    }
}

// 日付自動計算
function calculateDates() {
    const admissionDateInput = document.getElementById('admissionDate').value;
    if (!admissionDateInput) return;
    
    const admissionDate = new Date(admissionDateInput);
    
    // 90日後
    const ninetyDaysAfter = new Date(admissionDate);
    ninetyDaysAfter.setDate(ninetyDaysAfter.getDate() + 90);
    
    // 3か月後
    const threeMonthsAfter = new Date(admissionDate);
    threeMonthsAfter.setMonth(threeMonthsAfter.getMonth() + 3);
    
    // 入院期間
    const today = new Date();
    const admissionPeriod = Math.floor((today - admissionDate) / (1000 * 60 * 60 * 24));
    
    // 表示
    document.getElementById('ninetyDaysAfterDisplay').textContent = formatDate(ninetyDaysAfter.toISOString());
    document.getElementById('threeMonthsAfterDisplay').textContent = formatDate(threeMonthsAfter.toISOString());
    document.getElementById('admissionPeriodDisplay').textContent = admissionPeriod >= 0 ? `${admissionPeriod}日` : '-';
    
    document.getElementById('calculatedInfo').style.display = 'block';
}

// 入院期間計算
function calculateAdmissionPeriod(admissionDate) {
    const admission = new Date(admissionDate);
    const today = new Date();
    const days = Math.floor((today - admission) / (1000 * 60 * 60 * 24));
    return days >= 0 ? days : 0;
}

// 患者検索
function searchPatients() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    
    if (!searchTerm) {
        renderPatientsList();
        return;
    }
    
    const filteredPatients = allPatients.filter(p => 
        p.patientId.toLowerCase().includes(searchTerm) ||
        p.name.toLowerCase().includes(searchTerm)
    );
    
    const container = document.getElementById('patientsList');
    
    if (filteredPatients.length === 0) {
        container.innerHTML = '<p class="text-gray-500 text-center py-4">検索結果がありません</p>';
        return;
    }
    
    let html = `
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">患者番号</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">患者名</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">生年月日</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">病名</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">主治医</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">入院日</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ステータス</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">操作</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
    `;
    
    filteredPatients.forEach(patient => {
        const statusClass = patient.status === '入院中' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800';
        html += `
            <tr class="hover:bg-gray-50">
                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${patient.patientId}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${patient.name}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${formatDate(patient.dateOfBirth)}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${patient.disease}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${patient.primaryPhysician}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${formatDate(patient.admissionDate)}</td>
                <td class="px-6 py-4 whitespace-nowrap">
                    <span class="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${statusClass}">
                        ${patient.status}
                    </span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                    <button onclick="editPatient('${patient.id}')" class="text-blue-600 hover:text-blue-900">
                        <i class="fas fa-edit"></i> 編集
                    </button>
                    <button onclick="deletePatient('${patient.id}')" class="text-red-600 hover:text-red-900">
                        <i class="fas fa-trash"></i> 削除
                    </button>
                </td>
            </tr>
        `;
    });
    
    html += '</tbody></table>';
    container.innerHTML = html;
}

// CSVエクスポート
function exportToCSV() {
    if (allPatients.length === 0) {
        showNotification('エクスポートするデータがありません', 'warning');
        return;
    }
    
    // CSVヘッダー
    let csv = '患者番号,患者名,生年月日,病名,主治医,入院日,退院日,90日後,3か月後,入院期間(日),ステータス\n';
    
    // データ行
    allPatients.forEach(patient => {
        const row = [
            patient.patientId,
            patient.name,
            formatDate(patient.dateOfBirth),
            patient.disease,
            patient.primaryPhysician,
            formatDate(patient.admissionDate),
            patient.dischargeDate ? formatDate(patient.dischargeDate) : '',
            formatDate(patient.ninetyDaysAfter),
            formatDate(patient.threeMonthsAfter),
            patient.admissionPeriodDays || calculateAdmissionPeriod(patient.admissionDate),
            patient.status
        ];
        csv += row.join(',') + '\n';
    });
    
    // BOM付きUTF-8で出力
    const bom = new Uint8Array([0xEF, 0xBB, 0xBF]);
    const blob = new Blob([bom, csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    
    link.setAttribute('href', url);
    link.setAttribute('download', `患者情報_${formatDate(new Date().toISOString())}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    showNotification('CSVファイルをエクスポートしました', 'success');
}

// フォームリセット
function resetForm() {
    document.getElementById('patientForm').reset();
    document.getElementById('calculatedInfo').style.display = 'none';
}

// 日付フォーマット（表示用）
function formatDate(dateString) {
    if (!dateString) return '-';
    const date = new Date(dateString);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}/${month}/${day}`;
}

// 日付フォーマット（input用）
function formatDateForInput(dateString) {
    if (!dateString) return '';
    const date = new Date(dateString);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

// 通知表示
function showNotification(message, type = 'info') {
    const colors = {
        success: 'bg-green-500',
        error: 'bg-red-500',
        warning: 'bg-yellow-500',
        info: 'bg-blue-500'
    };
    
    const notification = document.createElement('div');
    notification.className = `fixed top-4 right-4 ${colors[type]} text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fade-in`;
    notification.innerHTML = `
        <div class="flex items-center space-x-2">
            <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
            <span>${message}</span>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.opacity = '0';
        notification.style.transition = 'opacity 0.5s';
        setTimeout(() => notification.remove(), 500);
    }, 3000);
}
